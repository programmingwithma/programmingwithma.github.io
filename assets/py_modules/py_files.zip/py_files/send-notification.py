from pynotifier import Notification


Notification(
	title='Notification Title',
	description='Notification Description',
	duration=5,
	urgency=Notification.URGENCY_CRITICAL
).send()
