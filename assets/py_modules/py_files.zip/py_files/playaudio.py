from playsound import playsound

playsound("reminder.mp3")
# This will play the "water.mp3" audio...

