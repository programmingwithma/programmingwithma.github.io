import time
from playsound import playsound
from pynotifier import Notification

water_time_drink = time.time()

interval = 1800
# interval = 20


while True:

    time_at_notification = water_time_drink + interval

    if time.time() >= time_at_notification:


        Notification(
            title='Water Drink Alert',
                description='It\'s Time To Drink Water.',
            duration=10,
            urgency=Notification.URGENCY_CRITICAL
        ).send()

        playsound("water.mp3")

        water_time_drink = time.time()



    else:

        time.sleep(time_at_notification - time.time())
