import time
initial_time = time.perf_counter()  # Recording the time before running loop

i = 1  # Initializing the counter

while i <= 100:
    print(i)
    i += 1

exit_time = time.perf_counter() # Recording the time after running loop

print("Time taken : ", exit_time - initial_time)
