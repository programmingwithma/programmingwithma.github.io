import time
from playsound import playsound
from pynotifier import Notification


present_time = time.localtime()

present_time_hour, present_time_min , present_second = present_time[3:6]

reminder_time = input("PLease enter the time for the reminder. \nPlease Enter the time in hh:mm and 24-hour format. \n ")
message = input("Enter Your Message : ")

reminder_hours , reminder_minutes = reminder_time.split(":")

reminder_seconds = int(reminder_hours) *3600 + int(reminder_minutes) *60

present_time_seconds = int(present_time_hour) *3600 + int(present_time_min) *60 + present_second

time.sleep(reminder_seconds - present_time_seconds)

for i in range(5):

    Notification(
        title='Reminder Alert',
        description= message ,
        duration=7,
        urgency=Notification.URGENCY_CRITICAL
    ).send()

    playsound("reminder.mp3")

print(present_time)