import time

# print(time.time_ns())
# print(time.time())


# print(time.localtime())
# print(time.gmtime())

# print(time.mktime(time.localtime()))
# print(time.mktime(time.gmtime()))

# print(time.monotonic())
# print(time.monotonic_ns())



# For perf_counter and perf_counter_ns--


# initial_time = time.perf_counter_ns()  # Recording the time before running loop
#
# i = 1  # Initializing the counter
#
# while i <= 100:
#     print(i)
#     i += 1
#
# exit_time = time.perf_counter_ns() # Recording the time after running loop
#
# print("Time taken : ", exit_time - initial_time)




# For time.sleep----

# while True:
#     print("Hello there!")
#     time.sleep(2)


# print(time.asctime(time.gmtime()))